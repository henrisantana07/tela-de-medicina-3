// Dashboard front-end: lista consultas, modifica e exclui (conectado com /api/consultas)

document.addEventListener("DOMContentLoaded", async () => {
  const totalConsultasEl = document.querySelector(".bg-1 h2");
  const totalPacientesEl = document.querySelector(".bg-2 h2");
  const listaMedicosEl = document.querySelector(".bg-3 ul");
  const tabelaBody = document.querySelector("tbody");
  const saudacaoEl = document.querySelector("p strong");
  const dataHojeEl = document.querySelector("small");

  // Modal de edição
  const editarModalEl = document.getElementById("editarModal");
  const editarModal = new bootstrap.Modal(editarModalEl);
  const formEditar = document.getElementById("formEditar");
  const inputConsultaId = document.getElementById("editarConsultaId");
  const selectPaciente = document.getElementById("editarPaciente");
  const selectMedico = document.getElementById("editarMedico");
  const inputData = document.getElementById("editarData");
  const inputHorario = document.getElementById("editarHorario");
  const editarFeedback = document.getElementById("editarFeedback");

  // =======================  
  // NOVO — Modal de exclusão  
  // =======================
  const modalExcluirEl = document.getElementById("modalExcluir");
  const modalExcluir = new bootstrap.Modal(modalExcluirEl);
  const btnConfirmarExcluir = document.getElementById("btnConfirmarExcluir");
  let idParaExcluir = null;

  btnConfirmarExcluir.addEventListener("click", async () => {
    if (!idParaExcluir) return;

    await cancelarConsulta(idParaExcluir);
    modalExcluir.hide();
    idParaExcluir = null;
  });
  // =======================

  // Obter usuário logado
  function getUsuarioLogado() {
    return (
      JSON.parse(localStorage.getItem("user")) ||
      JSON.parse(localStorage.getItem("usuario")) ||
      JSON.parse(localStorage.getItem("admin"))
    );
  }

  const user = getUsuarioLogado();
  if (!user) {
    alert("⚠️ Faça login para acessar o sistema.");
    window.location.href = "../login/views_login.html";
    return;
  }

  // Mostra nome e data atual
  const hojeStr = new Date().toLocaleDateString("pt-BR");
  dataHojeEl.textContent = hojeStr;
  saudacaoEl.textContent = user.nome || "Usuário";

  // Carrega médicos e pacientes para selects
  async function fetchPacientes() {
    const res = await fetch("http://localhost:3000/api/pacientes");
    return await res.json();
  }

  async function fetchMedicos() {
    const res = await fetch("http://localhost:3000/api/medicos");
    return await res.json();
  }

  // Carrega dashboard
  async function carregarDashboard() {
    try {
      const consultasRes = await fetch("http://localhost:3000/api/consultas");
      const consultas = await consultasRes.json();

      const pacientes = await fetchPacientes();
      const medicos = await fetchMedicos();

      totalPacientesEl.textContent = pacientes.length || 0;

      // Total de consultas do dia
      const hojeISO = new Date().toISOString().split("T")[0];
      const consultasHoje = consultas.filter((c) => c.data && c.data.startsWith(hojeISO));
      totalConsultasEl.textContent = consultasHoje.length;

      // Médicos
      const medicosMap = {};
      consultas.forEach((c) => {
        const nomeMed = c.medico || "Sem nome";
        if (!medicosMap[nomeMed]) medicosMap[nomeMed] = { especialidade: c.especialidade || "", total: 0 };
        medicosMap[nomeMed].total++;
      });

      listaMedicosEl.innerHTML = "";
      const nomesMedicos = Object.keys(medicosMap);
      if (nomesMedicos.length === 0) {
        listaMedicosEl.innerHTML = `<li class="small-muted">Nenhum dado</li>`;
      } else {
        nomesMedicos.forEach((nome) => {
          const info = medicosMap[nome];
          listaMedicosEl.innerHTML += `<li><strong>${nome}</strong> (${info.especialidade}) — ${info.total} consultas</li>`;
        });
      }

      // Tabela
      tabelaBody.innerHTML = "";
      if (!consultas.length) {
        tabelaBody.innerHTML = `<tr><td colspan="5" class="small-muted">Nenhum agendamento encontrado</td></tr>`;
      } else {
        consultas.forEach((c) => {
          tabelaBody.innerHTML += `
            <tr data-id="${c.id}">
              <td>${c.horario || "-"}</td>
              <td>${c.medico || "-"}</td>
              <td>${c.paciente || "-"}</td>
              <td>${c.data ? new Date(c.data).toLocaleDateString("pt-BR") : "-"}</td>
              <td>
                <div class="d-flex gap-2">
                  <button class="btn btn-sm btn-outline-primary btn-editar" data-id="${c.id}">
                    <i class="bi bi-pencil-square"></i> Editar
                  </button>

                  <button class="btn btn-sm btn-outline-danger btn-cancel" data-id="${c.id}">
                    <i class="bi bi-x-circle"></i> Excluir
                  </button>
                </div>
              </td>
            </tr>
          `;
        });
      }

      // Evento do botão EXCLUIR → abre modal (NADA visual foi alterado)
      document.querySelectorAll(".btn-cancel").forEach((btn) => {
        btn.addEventListener("click", () => {
          idParaExcluir = btn.getAttribute("data-id");  
          modalExcluir.show();
        });
      });

      // Evento do botão EDITAR
      document.querySelectorAll(".btn-editar").forEach((btn) => {
        btn.addEventListener("click", async () => {
          const id = btn.getAttribute("data-id");
          abrirModalEditar(id, pacientes, medicos);
        });
      });

    } catch (err) {
      console.error("Erro ao carregar dashboard:", err);
      alert("❌ Erro ao buscar dados do servidor.");
    }
  }

  // Cancelar consulta (DELETE)
  async function cancelarConsulta(id) {
    try {
      const res = await fetch(`http://localhost:3000/api/consultas/${id}`, { method: "DELETE" });

      if (!res.ok) {
        alert("Erro ao excluir consulta.");
        return;
      }

      alert("Consulta excluída com sucesso!");
      await carregarDashboard();

    } catch (err) {
      console.error(err);
      alert("Erro ao excluir consulta.");
    }
  }

  // Abrir modal editar
  async function abrirModalEditar(id, pacientesList = null, medicosList = null) {
    try {
      const [pacientes, medicos] = await Promise.all([
        pacientesList ? Promise.resolve(pacientesList) : fetchPacientes(),
        medicosList ? Promise.resolve(medicosList) : fetchMedicos(),
      ]);

      selectPaciente.innerHTML = pacientes.map(p => `<option value="${p.id}">${p.nome}</option>`).join("");
      selectMedico.innerHTML = medicos.map(m => `<option value="${m.id}">${m.nome} (${m.especialidade || ''})</option>`).join("");

      const res = await fetch(`http://localhost:3000/api/consultas/${id}`);
      const consulta = await res.json();

      inputConsultaId.value = consulta.id;

      if (consulta.data) {
        const d = new Date(consulta.data);
        inputData.value = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
      }

      inputHorario.value = consulta.horario ? consulta.horario.slice(0, 5) : "";

      if (consulta.paciente_id) selectPaciente.value = consulta.paciente_id;
      if (consulta.medico_id) selectMedico.value = consulta.medico_id;

      editarFeedback.textContent = "";
      editarModal.show();

    } catch (err) {
      console.error(err);
      alert("Erro ao abrir modal de edição.");
    }
  }

  // Salvar edição (PUT)
  formEditar.addEventListener("submit", async (ev) => {
    ev.preventDefault();

    const id = inputConsultaId.value;
    const paciente_id = selectPaciente.value;
    const medico_id = selectMedico.value;
    const data = inputData.value;
    let horario = inputHorario.value;

    if (!paciente_id || !medico_id || !data || !horario) {
      editarFeedback.textContent = "Preencha todos os campos.";
      return;
    }

    if (horario.length === 5) horario = horario + ":00";

    try {
      const res = await fetch(`http://localhost:3000/api/consultas/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ paciente_id, medico_id, data, horario })
      });

      if (!res.ok) {
        const err = await res.json();
        editarFeedback.textContent = err.error || "Erro ao atualizar.";
        return;
      }

      editarModal.hide();
      alert("Consulta atualizada com sucesso.");
      await carregarDashboard();

    } catch (err) {
      console.error(err);
      editarFeedback.textContent = "Erro de comunicação com o servidor.";
    }
  });

  await carregarDashboard();
});
