// Dashboard front-end: agora conectado com JOIN (relatório por usuário)

document.addEventListener("DOMContentLoaded", async () => {
  const totalConsultasEl = document.querySelector(".bg-1 h2");
  const totalPacientesEl = document.querySelector(".bg-2 h2");
  const listaMedicosEl = document.querySelector(".bg-3 ul");
  const tabelaBody = document.getElementById("tbody-funcionarios");
  const tabelaRelatorio = document.getElementById("tbody-relatorio");

  const saudacaoEl = document.querySelector("p strong");
  const dataHojeEl = document.querySelector("small");

  /* Modais e campos para Edição de Consulta */
  const editarModalEl = document.getElementById("editarModal");
  const editarModal = new bootstrap.Modal(editarModalEl);
  const formEditar = document.getElementById("formEditar");
  const editarFeedback = document.getElementById("editarFeedback");

  /* Modal editar usuário */
  const editarUsuarioModalEl = document.getElementById("editarUsuarioModal");
  const editarUsuarioModal = new bootstrap.Modal(editarUsuarioModalEl);
  const formEditarUsuario = document.getElementById("formEditarUsuario");
  const inputUserId = document.getElementById("editarUserId");
  const inputNome = document.getElementById("editarNome");
  const inputEmail = document.getElementById("editarEmail");
  const selectTipo = document.getElementById("editarTipo");
  const editarFeedbackUsuario = document.getElementById("editarFeedbackUsuario");

  /* NOVO — MODAL EXCLUSÃO USUÁRIO */
  const modalExcluirUserEl = document.getElementById("modalExcluirUser");
  const modalExcluirUser = new bootstrap.Modal(modalExcluirUserEl);
  const btnConfirmarExcluirUser = document.getElementById("btnConfirmarExcluirUser");
  let idUserParaExcluir = null;

  btnConfirmarExcluirUser.addEventListener("click", async () => {
    if (!idUserParaExcluir) return;
    await cancelarFuncionario(idUserParaExcluir);
    modalExcluirUser.hide();
    idUserParaExcluir = null;
  });

  let editarUserId = null;

  function getUsuarioLogado() {
    return (
      JSON.parse(localStorage.getItem("user")) ||
      JSON.parse(localStorage.getItem("usuario")) ||
      JSON.parse(localStorage.getItem("admin"))
    );
  }

  const user = getUsuarioLogado();
  if (!user) {
    alert("⚠️ Faça login para acessar o sistema.");
    window.location.href = "../../views_login.html";
    return;
  }

  const hojeStr = new Date().toLocaleDateString("pt-BR");
  dataHojeEl.textContent = hojeStr;
  saudacaoEl.textContent = user.nome || "Usuário";

  // =============== RELATÓRIO JOIN ==================
  async function carregarRelatorioUsuarios() {
    try {
      const hojeISO = new Date().toISOString().split("T")[0];
      const res = await fetch(`http://localhost:3000/api/reports/concluidas-por-funcionario?date=${hojeISO}`);
      const relatorio = await res.json();

      if (!tabelaRelatorio) return;

      tabelaRelatorio.innerHTML = "";
      if (relatorio.length === 0) {
        tabelaRelatorio.innerHTML = `<tr><td colspan="2">Nenhum dado encontrado</td></tr>`;
        return;
      }

      relatorio.forEach(r => {
        tabelaRelatorio.innerHTML += `
          <tr>
            <td>${r.nome}</td>
            <td>${r.concluidas}</td>
          </tr>
        `;
      });

    } catch (err) {
      console.error("Erro ao carregar relatório JOIN:", err);
    }
  }

  // ============================== CARREGAR DASHBOARD ==============================
  async function carregarDashboard() {
    try {
      const usersRes = await fetch("http://localhost:3000/api/users");
      const consultasRes = await fetch("http://localhost:3000/api/consultas");
      const pacientesRes = await fetch("http://localhost:3000/api/pacientes");

      const users = await usersRes.json();
      const consultas = await consultasRes.json();
      const pacientes = await pacientesRes.json();

      const medicosRes = await fetch("http://localhost:3000/api/medicos");
      const medicos = await medicosRes.json();

      totalPacientesEl.textContent = pacientes.length || 0;

      const hojeISO = new Date().toISOString().split("T")[0];
      const consultasHoje = consultas.filter(c => c.data && c.data.startsWith(hojeISO));
      totalConsultasEl.textContent = consultasHoje.length;

      const medicosMap = {};
      consultas.forEach(c => {
        const nomeMed = c.medico || "Sem nome";
        if (!medicosMap[nomeMed]) {
          medicosMap[nomeMed] = { especialidade: c.especialidade || "", total: 0 };
        }
        medicosMap[nomeMed].total++;
      });

      listaMedicosEl.innerHTML = "";
      Object.keys(medicosMap).forEach(nome => {
        const info = medicosMap[nome];
        listaMedicosEl.innerHTML += `
          <li><strong>${nome}</strong> (${info.especialidade}) — ${info.total} consultas</li>
        `;
      });

      await carregarFuncionarios();
      await carregarRelatorioUsuarios();

    } catch (err) {
      console.error(err);
    }
  }

  // ============================== LISTAR FUNCIONÁRIOS ==============================
  async function carregarFuncionarios() {
    try {
      const res = await fetch("http://localhost:3000/api/users");
      const funcionarios = await res.json();

      if (funcionarios.length === 0) {
        tabelaBody.innerHTML = `<tr><td colspan="5" class="small-muted">Nenhum funcionário cadastrado</td></tr>`;
        return;
      }

      tabelaBody.innerHTML = funcionarios.map(f => `
        <tr>
          <td>${f.nome}</td>
          <td>${f.email}</td>
          <td>${f.tipo}</td>
          <td>${new Date(f.criado_em).toLocaleDateString("pt-BR")}</td>
          <td>
            <div class="d-flex gap-2">
              <button class="btn btn-sm btn-outline-primary btn-editar" data-id="${f.id}">
                <i class="bi bi-pencil-square"></i> Editar
              </button>

              <button class="btn btn-sm btn-outline-danger btn-cancel" data-id="${f.id}">
                <i class="bi bi-x-circle"></i> cancelar
              </button>
            </div>
          </td>
        </tr>
      `).join("");

      document.querySelectorAll(".btn-cancel").forEach(btn => {
        btn.addEventListener("click", () => {
          idUserParaExcluir = btn.getAttribute("data-id");
          modalExcluirUser.show();
        });
      });

      document.querySelectorAll(".btn-editar").forEach(btn => {
        btn.addEventListener("click", () => {
          const id = btn.getAttribute("data-id");
          abrirModalEditar(id);
        });
      });

    } catch (err) {
      console.error(err);
    }
  }

  // ============================== DELETAR FUNCIONÁRIO ==============================
  async function cancelarFuncionario(id) {
    try {
      const res = await fetch(`http://localhost:3000/api/users/${id}`, {
        method: "DELETE",
      });

      if (!res.ok) {
        const err = await res.json();
        alert(err.error);
        return;
      }

      alert("Usuário removido com sucesso.");
      await carregarFuncionarios();
      await carregarRelatorioUsuarios();

    } catch (err) {
      console.error(err);
    }
  }

  // ============================== EDITAR FUNCIONÁRIO ==============================
  async function abrirModalEditar(id) {
    try {
      const res = await fetch(`http://localhost:3000/api/users/${id}`);
      const usuario = await res.json();

      editarUserId = usuario.id;
      inputUserId.value = usuario.id;
      inputNome.value = usuario.nome;
      inputEmail.value = usuario.email;
      selectTipo.value = usuario.tipo;

      editarFeedbackUsuario.textContent = "";
      editarUsuarioModal.show();

    } catch (error) {
      console.error(error);
      alert("Erro ao carregar dados do usuário.");
    }
  }

  formEditarUsuario.addEventListener("submit", async ev => {
    ev.preventDefault();

    const id = editarUserId;
    const nome = inputNome.value;
    const email = inputEmail.value;
    const tipo = selectTipo.value;

    try {
      const res = await fetch(`http://localhost:3000/api/users/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome, email, tipo }),
      });

      if (!res.ok) {
        const err = await res.json();
        editarFeedbackUsuario.textContent = err.error;
        return;
      }

      editarUsuarioModal.hide();
      await carregarFuncionarios();
      await carregarRelatorioUsuarios();

    } catch (error) {
      console.error(error);
    }
  });

  // ============================== INICIAR DASHBOARD ==============================
  await carregarDashboard();

  const logoutBtn = document.getElementById("btnLogout");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      localStorage.clear();
      window.location.href = "../../views_login.html";
    });
  }
});
