// consultas.js
document.addEventListener("DOMContentLoaded", () => {
  // função utilitária: tenta obter elemento por id, depois por name, retorna null se não encontrar
  function getEl(idOrName) {
    return document.getElementById(idOrName) || document.querySelector(`[name="${idOrName}"]`) || null;
  }

  const medicoSelect = getEl("medicoSelect");
  const pacienteSelect = getEl("pacienteSelect");
  const dataSelect = getEl("dataSelect");
  const horarioSelect = getEl("horarioSelect"); // pode ser <select> ou <input hidden>
  const tabela = getEl("tabela-consultas");
  const horariosContainer = getEl("horarios-container"); // caso você use a versão com botões

  // valida se elementos essenciais existem e loga mensagem clara
  if (!pacienteSelect) console.error('Elemento não encontrado: pacienteSelect (id ou name="pacienteSelect"). Verifique seu HTML.');
  if (!medicoSelect) console.error('Elemento não encontrado: medicoSelect (id ou name="medicoSelect"). Verifique seu HTML.');
  if (!dataSelect) console.error('Elemento não encontrado: dataSelect (id or name="dataSelect"). Verifique seu HTML.');
  if (!horarioSelect) console.warn('Elemento não encontrado: horarioSelect (id or name="horarioSelect"). Se usar botões, é normal.');
  if (!tabela) console.error('Elemento não encontrado: tabela-consultas (id="tabela-consultas"). Verifique seu HTML.');

  // helper: safe innerHTML set
  function safeSet(el, html) {
    if (!el) return;
    try { el.innerHTML = html; } catch (e) { console.error("Erro ao setar innerHTML:", e, el); }
  }

  // -------------------------
  // carregar pacientes
  // -------------------------
  async function carregarPacientes() {
    try {
      const res = await fetch("http://localhost:3000/api/pacientes");
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const pacientes = await res.json();

      if (!pacienteSelect) {
        console.error("Não foi possível preencher pacientes: elemento pacienteSelect ausente.");
        return;
      }

      // limpa (mantém a opção padrão se houver)
      const primeiraOpcao = pacienteSelect.querySelector("option[value='']")?.outerHTML || '<option value="">Selecione</option>';
      pacienteSelect.innerHTML = primeiraOpcao;

      if (!Array.isArray(pacientes) || pacientes.length === 0) {
        pacienteSelect.innerHTML = primeiraOpcao;
        console.info("Nenhum paciente retornado da API.");
        return;
      }

      pacientes.forEach(p => {
        // evite innerHTML acumulativo lento — usamos append
        const opt = document.createElement("option");
        opt.value = p.id;
        opt.textContent = p.nome;
        pacienteSelect.appendChild(opt);
      });

    } catch (err) {
      console.error("Erro ao carregar pacientes:", err);
    }
  }

  // -------------------------
  // carregar medicos
  // -------------------------
  async function carregarMedicos() {
    try {
      const res = await fetch("http://localhost:3000/api/medicos");
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const medicos = await res.json();

      if (!medicoSelect) {
        console.error("Não foi possível preencher médicos: elemento medicoSelect ausente.");
        return;
      }

      const primeiraOpcao = medicoSelect.querySelector("option[value='']")?.outerHTML || '<option value="">Selecione</option>';
      medicoSelect.innerHTML = primeiraOpcao;

      if (!Array.isArray(medicos) || medicos.length === 0) {
        medicoSelect.innerHTML = primeiraOpcao;
        console.info("Nenhum médico retornado da API.");
        return;
      }

      medicos.forEach(m => {
        const opt = document.createElement("option");
        opt.value = m.id;
        // armazenar horario_atendimento como atributo data para uso posterior
        if (m.horario_atendimento) opt.setAttribute("data-horario", m.horario_atendimento);
        opt.textContent = `${m.nome}${m.especialidade ? " - " + m.especialidade : ""}`;
        medicoSelect.appendChild(opt);
      });
    } catch (err) {
      console.error("Erro ao carregar médicos:", err);
    }
  }

  // -------------------------
  // gerar lista de horários simples (hora inteira)
  // -------------------------
  function gerarHorarios(inicio = "08:00", fim = "18:00") {
    const horarios = [];
    const hi = parseInt(inicio.split(":")[0], 10);
    const hf = parseInt(fim.split(":")[0], 10);
    for (let h = hi; h <= hf; h++) {
      horarios.push(String(h).padStart(2, "0") + ":00");
    }
    return horarios;
  }

  // -------------------------
  // atualizar horarios no <select> horarioSelect (quando médico muda)
  // -------------------------
  async function atualizarHorariosSelect() {
    if (!medicoSelect || !horarioSelect) return;

    // placeholder durante carregamento
    horarioSelect.innerHTML = `<option value="">Carregando...</option>`;

    const medicoID = medicoSelect.value;
    if (!medicoID) {
      horarioSelect.innerHTML = `<option value="">Selecione um médico</option>`;
      return;
    }

    try {
      const resp = await fetch(`http://localhost:3000/api/medicos/${medicoID}`);
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const medico = await resp.json();
      const texto = medico.horario_atendimento || "08:00-18:00";
      const [inicio, fim] = texto.split("-");
      const horarios = gerarHorarios(inicio, fim);

      // reconstruir select
      horarioSelect.innerHTML = `<option value="">Selecione...</option>`;
      horarios.forEach(h => {
        const o = document.createElement("option");
        o.value = h;
        o.textContent = h;
        horarioSelect.appendChild(o);
      });
    } catch (err) {
      console.error("Erro ao atualizar horários:", err);
      horarioSelect.innerHTML = `<option value="">Erro ao carregar horários</option>`;
    }
  }

  // -------------------------
  // carregar consultas (tabela)
  // -------------------------
  async function carregarConsultas() {
 
    if (!tabela) { console.warn("Tabela de consultas não encontrada."); return; }
    try {
      const res = await fetch("http://localhost:3000/api/consultas");
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const consultas = await res.json();

      // limpar tabela
      tabela.innerHTML = "";
      if (!Array.isArray(consultas) || consultas.length === 0) {
        safeSet(tabela, `<tr><td colspan="4" class="small-muted">Nenhum agendamento</td></tr>`);
        return;
      }

      consultas.forEach(c => {
        const tr = document.createElement("tr");
               const dataFormatada = new Date(c.data).toLocaleDateString("pt-BR");
        tr.innerHTML = `
          <td>${dataFormatada}</td>
          <td>${c.horario}</td>
          <td>${c.medico}</td>
          <td>${c.paciente}</td>
        `;
        tabela.appendChild(tr);
      });

    } catch (err) {
      console.error("Erro ao carregar consultas:", err);
      safeSet(tabela, `<tr><td colspan="4" class="text-danger">Erro ao carregar agendamentos</td></tr>`);
    }
  }

  // -------------------------
  // evento submit do form
  // -------------------------
  const form = document.getElementById("form-consulta");
  if (form) {
    form.addEventListener("submit", async (e) => {
      e.preventDefault();

      // obter IDs a partir do select ou elementos alternativos (name)
      const paciente_id = pacienteSelect ? pacienteSelect.value : (form.querySelector('[name="paciente_id"]')?.value || "");
      const medico_id = medicoSelect ? medicoSelect.value : (form.querySelector('[name="medico_id"]')?.value || "");
      const data = dataSelect ? dataSelect.value : (form.querySelector('[name="data"]')?.value || "");
      const horario = horarioSelect ? horarioSelect.value : (form.querySelector('[name="horario"]')?.value || "");

      if (!paciente_id || !medico_id || !data || !horario) {
        alert("Preencha todos os campos (paciente, médico, data e horário).");
        return;
      }

      try {
        const res = await fetch("http://localhost:3000/api/consultas", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ paciente_id, medico_id, data, horario })
        });

        const json = await res.json();
        if (!res.ok) {
          alert("Erro ao agendar: " + (json.error || res.statusText));
          return;
        }

        alert("Consulta agendada com sucesso!");
        await carregarConsultas();
      } catch (err) {
        console.error("Erro ao enviar formulário:", err);
        alert("Erro de comunicação com o servidor.");
      }
    });
  } else {
    console.warn("Formulário 'form-consulta' não encontrado no DOM.");
  }

  // -------------------------
  // events
  // -------------------------
  if (medicoSelect) medicoSelect.addEventListener("change", atualizarHorariosSelect);
  // se quiser atualizar horários também quando a data mudar e usar lógica de ocupação, adicione listener:
  // if (dataSelect) dataSelect.addEventListener("change", atualizarHorariosSelect);

  // -------------------------
  // inicialização
  // -------------------------
  carregarPacientes();
  carregarMedicos();
  carregarConsultas();

  // função extra para carregar médicos (chamada na inicialização)
  async function carregarMedicos() {
    // delega para a função assíncrona já definida acima para evitar duplicidade
    // nota: duplicidade evitada chamando a função já implementada mais acima
    try {
      await (async () => {
        const res = await fetch("http://localhost:3000/api/medicos");
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const medicos = await res.json();
        if (!medicoSelect) return;
        medicoSelect.innerHTML = `<option value="">Selecione</option>`;
        medicos.forEach(m => {
          const opt = document.createElement("option");
          opt.value = m.id;
          if (m.horario_atendimento) opt.setAttribute("data-horario", m.horario_atendimento);
          opt.textContent = `${m.nome}${m.especialidade ? " - " + m.especialidade : ""}`;
          medicoSelect.appendChild(opt);
        });
      })();
    } catch (err) {
      console.error("Erro ao carregar médicos (inicial):", err);
    }
  }

});
async function carregarConsultas() {
  if (!tabela) { 
    console.warn("Tabela de consultas não encontrada."); 
    return; 
  }

  try {
    const res = await fetch("http://localhost:3000/api/consultas");
    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    const consultas = await res.json();

    tabela.innerHTML = "";

    if (!Array.isArray(consultas) || consultas.length === 0) {
      safeSet(tabela, `<tr><td colspan="4" class="small-muted">Nenhum agendamento</td></tr>`);
      return;
    }

    consultas.forEach(c => {
      const tr = document.createElement("tr");

      // 👇 FORMATA DATA EM DD/MM/YYYY
      const dataFormatada = new Date(c.data).toLocaleDateString("pt-BR");

      tr.innerHTML = `
        <td>${dataFormatada}</td>
        <td>${c.horario}</td>
        <td>${c.medico}</td>
        <td>${c.paciente}</td>
      `;

      tabela.appendChild(tr);
    });

  } catch (err) {
    console.error("Erro ao carregar consultas:", err);
    safeSet(tabela, `<tr><td colspan="4" class="text-danger">Erro ao carregar agendamentos</td></tr>`);
  }
}
