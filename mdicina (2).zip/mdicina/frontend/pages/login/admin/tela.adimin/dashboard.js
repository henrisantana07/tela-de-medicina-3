let pieChart, lineChart, barChart;

/* ============================
   BUSCA DADOS DO BACKEND REAL
   ============================ */
async function fetchReportData(date) {
  const res = await fetch(`http://localhost:3000/api/reports/summary?date=${date}`);
  if (!res.ok) throw new Error("Erro ao buscar relatório resumido");
  return await res.json();
}

async function fetchStaffData(date) {
  const res = await fetch(`http://localhost:3000/api/reports/concluidas-por-funcionario?date=${date}`);
  if (!res.ok) throw new Error("Erro ao buscar relatório por funcionário");
  return await res.json();
}



  // === LINHA ===
  const lineCtx = document.getElementById("lineChart").getContext("2d");
  lineChart = new Chart(lineCtx, {
    type: "line",
    data: { labels: [], datasets: [{
      label: "Consultas Marcads",
      data: [],
      borderColor: "#fae206ff",
      backgroundColor: "rgba(185, 157, 0, 0.48)",
      fill: true,
      tension: 0.3
    }] }
  });

/* ============================
      INICIALIZAÇÃO DOS GRÁFICOS
   ============================ */
function initCharts() {
  // === PIZZA ===
  const pieCtx = document.getElementById("pieChart").getContext("2d");
  pieChart = new Chart(pieCtx, {
    type: "pie",
    data: {
      
      labels: ["Agendadas"],
      datasets: [{
        data: [],
        backgroundColor: ["#ffc107"]
      }]
    },
    options: { responsive: true }
  });

  // === BARRAS ===
  const barCtx = document.getElementById("barChart").getContext("2d");
  barChart = new Chart(barCtx, {
    type: "bar",
    data: {
      labels: [],
      datasets: [{
        label: "Agendadas",
        data: [],
        backgroundColor: "#ffc107"
      }]
    },
    options: { responsive: true, scales: { y: { beginAtZero: true } } }
  });
}


/* ===================================
      ATUALIZA O DASHBOARD NO PAINEL
   =================================== */
async function updateDashboard(date) {
  try {
    const resumo = await fetchReportData(date);
    const staff = await fetchStaffData(date);

    document.getElementById("total-consultas").textContent = resumo.totalConsultas;
    document.getElementById("medicos-disponiveis").textContent = resumo.medicosDisponiveis;
    document.getElementById("agendadas").textContent = resumo.agendadas;

    // === PIZZA ===
    pieChart.data.datasets[0].data = [
      resumo.agendadas,
      resumo.canceladas
    ];
    pieChart.update();

    // === LINHA ===
    lineChart.data.labels = resumo.series.map(s => s.date);
    lineChart.data.datasets[0].data = resumo.series.map(s => s.total);
    lineChart.update();

    // === BARRAS ===
    barChart.data.labels = staff.map(s => s.nome);
    barChart.data.datasets[0].data = staff.map(s => s.concluidas);
    barChart.update();

    document.getElementById("last-updated").textContent = new Date().toLocaleString();

  } catch (err) {
    console.error("Erro dashboard:", err);
    alert("Erro ao atualizar dados.");
  }
}

/* ============================
        PDF COM jsPDF
   ============================ */
async function generatePDF() {
  const btn = document.getElementById("print-pdf-btn");
  btn.disabled = true;

  try {
    const area = document.getElementById("report-area");
    const canvas = await html2canvas(area, { scale: 2 });
    const img = canvas.toDataURL("image/png");

    const pdf = new jspdf.jsPDF("p", "pt", "a4");
    const w = pdf.internal.pageSize.getWidth();
    const h = canvas.height * (w / canvas.width);

    pdf.addImage(img, "PNG", 0, 10, w, h);
    pdf.save("relatorio-consultas.pdf");

  } catch (err) {
    console.error(err);
    alert("Erro ao gerar PDF");
  }

  btn.disabled = false;
}

/* ============================
        IMPRIMIR NAVEGADOR
   ============================ */
function printBrowser() {
  window.print();
}

/* ===============================
           START DO PAINEL
   =============================== */
document.addEventListener("DOMContentLoaded", async () => {
  initCharts();

  const dateInput = document.getElementById("date-filter");
  dateInput.value = new Date().toISOString().slice(0, 10);

  await updateDashboard(dateInput.value);

  document.getElementById("refresh-btn")
    .addEventListener("click", () => updateDashboard(dateInput.value));

  document.getElementById("print-browser-btn")
    .addEventListener("click", printBrowser);

  document.getElementById("print-pdf-btn")
    .addEventListener("click", generatePDF);
});
