// script.js - Login de usuário
document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector("form");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const email = form.email.value.trim();
    const senha = form.senha.value.trim();

    if (!email || !senha) {
      alert("Por favor, preencha todos os campos!");
      return;
    }

    try {
      const response = await fetch("http://localhost:3000/api/users/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, senha }),
      });

      const data = await response.json();

      if (response.ok) {
        alert(`✅ Login realizado com sucesso! Bem-vindo(a), ${data.user.nome}`);

        // Armazena informações do usuário (exemplo simples)
        localStorage.setItem("usuario", JSON.stringify(data.user));

        // Redireciona conforme o tipo
        if (data.user.tipo === "admin") {
          window.location.href = "admin/tela.adimin/tela_admin.html";
        } else {
          window.location.href = "recepção/recepcao.html";
        }
      } else {
        alert(`⚠️ Erro: ${data.error || "Credenciais inválidas"}`);
      }
    } catch (err) {
      console.error("Erro ao fazer login:", err);
      alert("❌ Erro de conexão com o servidor.");
    }
  });
});
