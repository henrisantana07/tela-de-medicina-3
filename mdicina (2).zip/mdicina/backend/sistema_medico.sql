-- Schema para o sistema de agendamento médico
CREATE DATABASE IF NOT EXISTS agenda_medica CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE agenda_medica;

-- Usuários do sistema
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  senha VARCHAR(255) NOT NULL,
  tipo ENUM('admin','recepcao','medico') DEFAULT 'recepcao' ,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Pacientes
CREATE TABLE IF NOT EXISTS pacientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(150) NOT NULL,
  cpf VARCHAR(20) UNIQUE,
  telefone VARCHAR(50),
  data_nascimento DATE,
  endereco VARCHAR(255),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Médicos
CREATE TABLE IF NOT EXISTS medicos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(150) NOT NULL UNIQUE,
  nome VARCHAR(150) NOT NULL,
  especialidade VARCHAR(100),
  crm VARCHAR(50) UNIQUE,
  horario_atendimento VARCHAR(255), -- string descritiva ou JSON leve
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Consultas
CREATE TABLE IF NOT EXISTS consultas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  paciente_id INT NOT NULL,
  medico_id INT NOT NULL,
  data DATE NOT NULL,
  horario TIME NOT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (paciente_id) REFERENCES pacientes(id) ON DELETE CASCADE,
  FOREIGN KEY (medico_id) REFERENCES medicos(id) ON DELETE CASCADE,
  UNIQUE KEY unico_medico_data_hora (medico_id, data, horario) -- regra para evitar duplicados
);

-- Seed de exemplo
INSERT IGNORE INTO users (nome, email, senha, tipo)
VALUES ('Administrador', 'admin@example.com', '$2b$10$placeholder_for_hashed_password', 'admin');
select* from consultas;
select* from medicos;
select* from users;