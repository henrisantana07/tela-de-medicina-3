const express = require('express');
const router = express.Router();
const pool = require('../db');


// Criar paciente
router.post('/', async (req, res) => {
    try {
        const { nome, cpf, telefone, data_nascimento, endereco } = req.body;
        const [result] = await pool.query(
            'INSERT INTO pacientes (nome, cpf, telefone, data_nascimento, endereco) VALUES (?, ?, ?, ?, ?)',
            [nome, cpf, telefone, data_nascimento, endereco]
        );
        res.status(201).json({ id: result.insertId, nome });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao criar paciente' });
    }
});


// Listar todos
router.get('/', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM pacientes ORDER BY nome');
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao listar pacientes' });
    }
});


// Buscar por id
router.get('/:id', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM pacientes WHERE id = ?', [req.params.id]);
        if (!rows.length) return res.status(404).json({ error: 'Paciente não encontrado' });
        res.json(rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro no servidor' });
    }
});


// Atualizar
router.put('/:id', async (req, res) => {
    try {
        const { nome, cpf, telefone, data_nascimento, endereco } = req.body;
        await pool.query(
            'UPDATE pacientes SET nome = ?, cpf = ?, telefone = ?, data_nascimento = ?, endereco = ? WHERE id = ?',
            [nome, cpf, telefone, data_nascimento, endereco, req.params.id]
        );
        res.json({ message: 'Paciente atualizado' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao atualizar paciente' });
    }
});


// Deletar
router.delete('/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM pacientes WHERE id = ?', [req.params.id]);
        res.json({ message: 'Paciente removido' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao remover paciente' });
    }
});


module.exports = router;