const express = require('express');
const router = express.Router();
const pool = require('../db');

// GET /api/reports/summary?date=YYYY-MM-DD
// Retorna resumo das consultas para a data especificada e série dos últimos 7 dias
router.get('/summary', async (req, res) => {
  try {
    const { date } = req.query;
    if (!date) return res.status(400).json({ error: 'Parâmetro date obrigatório' });

    // Contagens para a data específica
    const [consultasRows] = await pool.query(
      `SELECT
        COUNT(*) AS totalConsultas,
        0 AS concluidas,
        COUNT(*) AS agendadas
       FROM consultas
       WHERE data = ?`,
      [date]
    );

    // Médicos disponíveis hoje (simplificado: todos os médicos)
    const [medicosRows] = await pool.query('SELECT COUNT(*) AS medicosDisponiveis FROM medicos');

    // Canceladas: assumindo que consultas passadas sem registro de conclusão são canceladas (simplificado)
    // Para precisão, pode adicionar campo status na tabela consultas
    const canceladas = 0; // Placeholder, ajustar conforme necessidade

    // Série dos últimos 7 dias
    const series = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(date);
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().slice(0, 10);
      const [seriesRow] = await pool.query('SELECT COUNT(*) AS total FROM consultas WHERE data = ?', [dateStr]);
      series.push({ date: dateStr, total: seriesRow[0].total });
    }

    const data = consultasRows[0];
    res.json({
      totalConsultas: data.totalConsultas,
      medicosDisponiveis: medicosRows[0].medicosDisponiveis,
      canceladas,
      concluidas: data.concluidas,
      agendadas: data.agendadas,
      series
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao buscar resumo' });
  }
});

// GET /api/reports/concluidas-por-funcionario?date=YYYY-MM-DD
// Retorna consultas concluídas por médico para a data
router.get('/concluidas-por-funcionario', async (req, res) => {
  try {
    const { date } = req.query;
    if (!date) return res.status(400).json({ error: 'Parâmetro date obrigatório' });

    const [rows] = await pool.query(
      `SELECT m.nome, COUNT(c.id) AS concluidas
       FROM medicos m
       LEFT JOIN consultas c ON m.id = c.medico_id AND c.data = ?
       GROUP BY m.id, m.nome
       ORDER BY concluidas DESC`,
      [date]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao buscar consultas por funcionário' });
  }
});

module.exports = router;
