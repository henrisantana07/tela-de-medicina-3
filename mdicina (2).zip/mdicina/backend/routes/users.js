const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const pool = require('../db');


// Registrar usuário (somente admin exemplificado)
router.post('/register', async (req, res) => {
try {
const { nome, email, senha, tipo } = req.body;
if (!nome || !email || !senha) return res.status(400).json({ error: 'Campos obrigatórios' });


const [exists] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
if (exists.length) return res.status(400).json({ error: 'Email já cadastrado' });


const hash = await bcrypt.hash(senha, 10);
const [result] = await pool.query('INSERT INTO users (nome, email, senha, tipo) VALUES (?, ?, ?, ?)', [nome, email, hash, tipo || 'recepcao']);
res.status(201).json({ id: result.insertId, nome, email });
} catch (err) {
console.error(err);
res.status(500).json({ error: 'Erro no servidor' });
}
});


// Login simples (retorna usuário sem token para didática)
router.post('/login', async (req, res) => {
try {
const { email, senha } = req.body;
if (!email || !senha) return res.status(400).json({ error: 'Campos obrigatórios' });


const [rows] = await pool.query('SELECT id, nome, email, senha, tipo FROM users WHERE email = ?', [email]);
if (!rows.length) return res.status(400).json({ error: 'Usuário não encontrado' });


const user = rows[0];
const match = await bcrypt.compare(senha, user.senha);
if (!match) return res.status(401).json({ error: 'Senha incorreta e/ou e-mail incorreto' });


// Para simplicidade, retornamos os dados do usuário (não recomendamos em produção sem token)
delete user.senha;
res.json({ user });
} catch (err) {
console.error(err);
res.status(500).json({ error: 'Erro no servidor' });
}
});

// Listar todos os usuários
router.get('/', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT id, nome, email, tipo, criado_em FROM users ORDER BY nome');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao listar usuários' });
  }
});

// Buscar usuário por id
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT id, nome, email, tipo, criado_em FROM users WHERE id = ?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Usuário não encontrado' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro no servidor' });
  }
});

// Atualizar usuário
router.put('/:id', async (req, res) => {
  try {
    const { nome, email, tipo } = req.body;
    const [result] = await pool.query('UPDATE users SET nome = ?, email = ?, tipo = ? WHERE id = ?', [nome, email, tipo, req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Usuário não encontrado' });
    res.json({ message: 'Usuário atualizado' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao atualizar usuário' });
  }
});

// Deletar usuário
router.delete('/:id', async (req, res) => {
  try {
    const [result] = await pool.query('DELETE FROM users WHERE id = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Usuário não encontrado' });
    res.json({ message: 'Usuário removido' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao remover usuário' });
  }
});



// Relatório de usuários com total de consultas e última consulta (JOIN)
router.get('/relatorio/consultas', async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT 
        f.id,
        f.nome,
        f.email,
        f.tipo,
        COUNT(c.id) AS total_consultas,
        MAX(c.data) AS ultima_consulta
      FROM users u
      LEFT JOIN consultas c ON c.user_id = u.id
      GROUP BY u.id, u.nome, u.email, u.tipo
      ORDER BY u.nome
    `);

    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao gerar relatório de consultas dos usuários' });
  }
});

module.exports = router;
