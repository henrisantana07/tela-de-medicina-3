const express = require('express');
const router = express.Router();
const pool = require('../db');

// Agendar consulta — verifica disponibilidade com a constraint UNIQUE criada no DB
router.post('/', async (req, res) => {
  try {
    const { paciente_id, medico_id, data, horario } = req.body;
    if (!paciente_id || !medico_id || !data || !horario) return res.status(400).json({ error: 'Campos obrigatórios' });

    try {
      const [result] = await pool.query(
        'INSERT INTO consultas (paciente_id, medico_id, data, horario) VALUES (?, ?, ?, ?)',
        [paciente_id, medico_id, data, horario]
      );
      res.status(201).json({ id: result.insertId, paciente_id, medico_id, data, horario });
    } catch (dbErr) {
      // erro de duplicidade (MySQL errno 1062)
      if (dbErr && dbErr.errno === 1062) {
        return res.status(409).json({ error: 'Horário já agendado para esse médico' });
      }
      throw dbErr;
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao agendar consulta' });
  }
});

// Listar consultas (com joins para retornar dados legíveis)
router.get('/', async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT c.id, c.data, c.horario, c.paciente_id, c.medico_id, p.nome AS paciente, m.nome AS medico, m.especialidade
       FROM consultas c
       JOIN pacientes p ON c.paciente_id = p.id
       JOIN medicos m ON c.medico_id = m.id
       ORDER BY c.data, c.horario`
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao listar consultas' });
  }
});

// Buscar uma consulta por id (retorna ids para edição)
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT c.id, c.data, c.horario, c.paciente_id, c.medico_id, p.nome AS paciente, m.nome AS medico, m.especialidade
       FROM consultas c
       JOIN pacientes p ON c.paciente_id = p.id
       JOIN medicos m ON c.medico_id = m.id
       WHERE c.id = ?`,
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Consulta não encontrada' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao buscar consulta' });
  }
});

// Atualizar consulta
router.put('/:id', async (req, res) => {
  try {
    const { paciente_id, medico_id, data, horario } = req.body;
    if (!paciente_id || !medico_id || !data || !horario) return res.status(400).json({ error: 'Campos obrigatórios' });

    try {
      const [result] = await pool.query(
        'UPDATE consultas SET paciente_id = ?, medico_id = ?, data = ?, horario = ? WHERE id = ?',
        [paciente_id, medico_id, data, horario, req.params.id]
      );
      if (result.affectedRows === 0) return res.status(404).json({ error: 'Consulta não encontrada' });
      res.json({ message: 'Consulta atualizada' });
    } catch (dbErr) {
      if (dbErr && dbErr.errno === 1062) {
        return res.status(409).json({ error: 'Horário já agendado para esse médico' });
      }
      throw dbErr;
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao atualizar consulta' });
  }
});

// Cancelar consulta
router.delete('/:id', async (req, res) => {
  try {
    
    const [result] = await pool.query('DELETE FROM consultas WHERE id = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Consulta não encontrada' });
    res.json({ message: 'Consulta cancelada' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao cancelar consulta' });
  }
});


module.exports = router;