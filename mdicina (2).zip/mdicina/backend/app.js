const express = require('express');
const cors = require('cors');
require('dotenv').config();
const path = require('path');

// Rotas da API
const usersRouter = require('./routes/users');
const pacientesRouter = require('./routes/pacientes');
const medicosRouter = require('./routes/medicos');
const consultasRouter = require('./routes/consultas');
const reportsRouter = require('./routes/reports');

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());

// Permitir servir arquivos estáticos do frontend
app.use(express.static(path.join(__dirname, "frontend")));

// Rotas da API
app.use('/api/users', usersRouter);
app.use('/api/pacientes', pacientesRouter);
app.use('/api/medicos', medicosRouter);
app.use('/api/consultas', consultasRouter);
app.use('/api/reports', reportsRouter);

// Rota raiz
app.get('/', (req, res) => {
    res.send('API Agenda Médica - OK');
});

// Iniciar servidor
const port = process.env.PORT || 3000;
app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});
