# TODO: Corrigir botões de editar e excluir na página de recepção

## Passos a serem completados:

- [x] Editar recepcao.html para adicionar o select de médico no modal de edição.
- [x] Editar recepcao.js para consolidar a função abrirModalEditar dentro do escopo com tratamento de erro melhorado.
- [x] Atualizar a função cancelarConsulta para lidar com respostas de erro não-JSON.
- [x] Alterar o texto do botão de "cancelar" para "Excluir".
